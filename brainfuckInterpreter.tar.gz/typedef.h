#pragma once
#define bool char
#define false 0
#define true 1
#define nullptr 0
